PROJECT HOME:

	https://github.com/pswitl1/cosc432_group_project

USAGE:

	source env/bin/activate
	./main.py training_data_input_file.txt --use-stopwords --dropout
